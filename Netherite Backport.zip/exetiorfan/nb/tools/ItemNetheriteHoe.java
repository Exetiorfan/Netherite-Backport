package exetiorfan.nb.tools;

import exetiorfan.nb.NetheriteBackport;
import exetiorfan.nb.entity.FireproofItemEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemNetheriteHoe extends ItemHoe {

	public ItemNetheriteHoe(ToolMaterial material) {
		super(material);
		
	}
	public boolean hasCustomEntity(final ItemStack stack) {
	    return true;
	}

	public Entity createEntity(final World world, final Entity location, final ItemStack itemstack) {
	    return (Entity)new FireproofItemEntity(world, location, itemstack);
	}
    @Override
    public boolean getIsRepairable(ItemStack itemToRepair, ItemStack itemToRepairWith)
    {
    	if(itemToRepairWith.getItem() == NetheriteBackport.itemNetheriteIngot && itemToRepairWith.getItemDamage() == 0)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }

}
