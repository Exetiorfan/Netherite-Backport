package exetiorfan.nb.blocks;

import exetiorfan.nb.sounds.ModSounds;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockNetheriteBlock extends Block { 

	public BlockNetheriteBlock(Material material) {
		super(material.rock);
		this.setStepSound(ModSounds.soundNetherite);
		this.setResistance(2000.0F);
		this.setHardness(50.0F);
		this.setHarvestLevel("pickaxe", 3);
	}

    @Override
    public boolean isBeaconBase (IBlockAccess worldObj, int x, int y, int z, int beaconX, int beaconY, int beaconZ)
    {
        return true;
    }
}