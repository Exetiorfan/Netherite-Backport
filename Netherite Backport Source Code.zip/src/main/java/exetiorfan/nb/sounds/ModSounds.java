package exetiorfan.nb.sounds;

import net.minecraft.block.Block;

public class ModSounds {
	
	public static final Block.SoundType soundDebris = new Block.SoundType("Debris", 1.0f, 1.0f) {
		public String getBreakSound() {
		      return "nb:debris.break";
		}

	public String getStepResourcePath() {
		return "nb:debris.step";
	    }
    };
    
	public static final Block.SoundType soundNetherite = new Block.SoundType("Netherite", 1.0f, 1.0f) {
		public String getBreakSound() {
		      return "nb:netherite.break";
		}

	public String getStepResourcePath() {
		return "nb:netherite.step";
	    }
    };

}