package exetiorfan.nb;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import exetiorfan.nb.armor.ItemNetheriteArmor;
import exetiorfan.nb.blocks.BlockAncientDebris;
import exetiorfan.nb.blocks.BlockNetheriteBlock;
import exetiorfan.nb.blocks.ItemBlockAncientDebris;
import exetiorfan.nb.blocks.ItemBlockNetheriteBlock;
import exetiorfan.nb.entity.FireproofItemEntity;
import exetiorfan.nb.generation.AncientDebrisGeneration;
import exetiorfan.nb.items.ItemNetheriteIngot;
import exetiorfan.nb.items.ItemNetheriteScrap;
import exetiorfan.nb.tools.ItemNetheriteAxe;
import exetiorfan.nb.tools.ItemNetheriteHoe;
import exetiorfan.nb.tools.ItemNetheritePickaxe;
import exetiorfan.nb.tools.ItemNetheriteShovel;
import exetiorfan.nb.tools.ItemNetheriteSword;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemSign;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

@Mod(modid = "NetheriteBackport", name = "Netherite Backport", version = "1.7")
public class NetheriteBackport {
	
	public static Item itemNetheriteIngot;
	public static Item itemNetheriteScrap;
	
	public static Item itemNetheriteSword;
	public static Item itemNetheriteShovel;
	public static Item itemNetheritePickaxe;
	public static Item itemNetheriteAxe;
	public static Item itemNetheriteHoe;
	
	public static Item itemNetheriteHelmet;
	public static Item itemNetheriteChestplate;
	public static Item itemNetheriteLeggings;
	public static Item itemNetheriteBoots;
	
	public static Block blockAncientDebris;
	public static Block blockNetheriteBlock;
	
	public static final Item.ToolMaterial netheriteToolMaterial = EnumHelper.addToolMaterial("netheriteToolMaterial", 4, 2031, 10.0F, 4.0F, 15);
	public static final ItemArmor.ArmorMaterial netheriteArmorMaterial = EnumHelper.addArmorMaterial("netheriteArmourMaterial", 37, new int[]{3,8,6,3}, 15);
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		//Item/Block init and registering
		//Config handling
		
		itemNetheriteIngot = new ItemNetheriteIngot().setUnlocalizedName("netherite_ingot").setTextureName("nb:netherite_ingot").setCreativeTab(tabNetheriteBackport);
		GameRegistry.registerItem(itemNetheriteIngot, itemNetheriteIngot.getUnlocalizedName().substring(5));
		itemNetheriteScrap = new ItemNetheriteScrap().setUnlocalizedName("netherite_scrap").setTextureName("nb:netherite_scrap").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteScrap, itemNetheriteScrap.getUnlocalizedName().substring(5));
		
		itemNetheriteSword = new ItemNetheriteSword(netheriteToolMaterial).setUnlocalizedName("netherite_sword").setTextureName("nb:netherite_sword").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteSword, itemNetheriteSword.getUnlocalizedName().substring(5));
		itemNetheriteShovel = new ItemNetheriteShovel(netheriteToolMaterial).setUnlocalizedName("netherite_shovel").setTextureName("nb:netherite_shovel").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteShovel, itemNetheriteShovel.getUnlocalizedName().substring(5));
		itemNetheritePickaxe = new ItemNetheritePickaxe(netheriteToolMaterial).setUnlocalizedName("netherite_pickaxe").setTextureName("nb:netherite_pickaxe").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheritePickaxe, itemNetheritePickaxe.getUnlocalizedName().substring(5));
		itemNetheriteAxe = new ItemNetheriteAxe(netheriteToolMaterial).setUnlocalizedName("netherite_axe").setTextureName("nb:netherite_axe").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteAxe, itemNetheriteAxe.getUnlocalizedName().substring(5));
		itemNetheriteHoe = new ItemNetheriteHoe(netheriteToolMaterial).setUnlocalizedName("netherite_hoe").setTextureName("nb:netherite_hoe").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteHoe, itemNetheriteHoe.getUnlocalizedName().substring(5));
		
		itemNetheriteHelmet = new ItemNetheriteArmor(netheriteArmorMaterial, 0, 0).setUnlocalizedName("netherite_helmet").setTextureName("nb:netherite_helmet").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteHelmet, itemNetheriteHelmet.getUnlocalizedName().substring(5));
		itemNetheriteChestplate = new ItemNetheriteArmor(netheriteArmorMaterial, 0, 1).setUnlocalizedName("netherite_chestplate").setTextureName("nb:netherite_chestplate").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteChestplate, itemNetheriteChestplate.getUnlocalizedName().substring(5));
		itemNetheriteLeggings = new ItemNetheriteArmor(netheriteArmorMaterial, 0, 2).setUnlocalizedName("netherite_leggings").setTextureName("nb:netherite_leggings").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteLeggings, itemNetheriteLeggings.getUnlocalizedName().substring(5));
		itemNetheriteBoots = new ItemNetheriteArmor(netheriteArmorMaterial, 0, 3).setUnlocalizedName("netherite_boots").setTextureName("nb:netherite_boots").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerItem(itemNetheriteBoots, itemNetheriteBoots.getUnlocalizedName().substring(5));
		
		blockAncientDebris = new BlockAncientDebris(Material.rock).setBlockName("ancient_debris").setCreativeTab(tabNetheriteBackport);
		GameRegistry.registerBlock(blockAncientDebris, ItemBlockAncientDebris.class, blockAncientDebris.getUnlocalizedName().substring(5));
		System.out.println(blockAncientDebris.getUnlocalizedName().substring(5));
        blockNetheriteBlock = new BlockNetheriteBlock(Material.rock).setBlockName("netherite_block").setBlockTextureName("nb:netherite_block").setCreativeTab(tabNetheriteBackport);;
		GameRegistry.registerBlock(blockNetheriteBlock, ItemBlockNetheriteBlock.class, blockNetheriteBlock.getUnlocalizedName().substring(5));
		System.out.println(blockNetheriteBlock.getUnlocalizedName().substring(5));
		
		AncientDebrisGeneration.mainRegistry();
		
		EntityRegistry.registerModEntity(FireproofItemEntity.class, "FireproofItemEntity", 69, "NetheriteBackport", 82, 3, true);
	}

	@EventHandler
	public void init(FMLInitializationEvent event) {
		//Proxy, TileEntity, entity, GUI and Packet Registering
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteIngot), NetheriteBackport.itemNetheriteScrap, NetheriteBackport.itemNetheriteScrap, NetheriteBackport.itemNetheriteScrap, NetheriteBackport.itemNetheriteScrap, Items.gold_ingot, Items.gold_ingot, Items.gold_ingot, Items.gold_ingot);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteIngot, 9), NetheriteBackport.blockNetheriteBlock);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.blockNetheriteBlock), NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot, NetheriteBackport.itemNetheriteIngot);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteSword), NetheriteBackport.itemNetheriteIngot, Items.diamond_sword);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteShovel), NetheriteBackport.itemNetheriteIngot, Items.diamond_shovel);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheritePickaxe), NetheriteBackport.itemNetheriteIngot, Items.diamond_pickaxe);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteAxe), NetheriteBackport.itemNetheriteIngot, Items.diamond_axe);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteHoe), NetheriteBackport.itemNetheriteIngot, Items.diamond_hoe);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteHelmet), NetheriteBackport.itemNetheriteIngot, Items.diamond_helmet);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteChestplate), NetheriteBackport.itemNetheriteIngot, Items.diamond_chestplate);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteLeggings), NetheriteBackport.itemNetheriteIngot, Items.diamond_leggings);
		GameRegistry.addShapelessRecipe(new ItemStack(NetheriteBackport.itemNetheriteBoots), NetheriteBackport.itemNetheriteIngot, Items.diamond_boots);
		GameRegistry.addSmelting(blockAncientDebris, new ItemStack(NetheriteBackport.itemNetheriteScrap), 2.0F);
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
	}
	
	public static CreativeTabs tabNetheriteBackport = new CreativeTabs("tabNetheriteBackport") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(itemNetheriteIngot).getItem();
		}
	};
}
