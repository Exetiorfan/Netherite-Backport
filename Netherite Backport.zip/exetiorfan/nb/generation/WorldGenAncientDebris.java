package exetiorfan.nb.generation;

import java.util.Random;

import cpw.mods.fml.common.IWorldGenerator;
import exetiorfan.nb.NetheriteBackport;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;

public class WorldGenAncientDebris implements IWorldGenerator{
	
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
		switch(world.provider.dimensionId) {
		case -1:
		generateNether(world, random, chunkX * 16, chunkZ * 16);
		}
	}

	public void generateNether(final World world, final Random random, final int x, final int z) {
        for (int i = 0; i < 1; ++i) {
			final int randPosX = x + random.nextInt(16);
			final int randPosY = 5 + random.nextInt(117);
			final int randPosZ = z + random.nextInt(16);
			(new WorldGenMinable(NetheriteBackport.blockAncientDebris, 0, 4, Blocks.netherrack)).generate(world, random, randPosX, randPosY, randPosZ);
		}
	}
}