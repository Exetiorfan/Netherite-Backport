package exetiorfan.nb.blocks;

import exetiorfan.nb.entity.FireproofItemEntity;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemBlockNetheriteBlock extends ItemBlock {
	
	public ItemBlockNetheriteBlock(Block material) {
		super(material);
		
	}

	public boolean hasCustomEntity(final ItemStack stack) {
	    return true;
	}

	public Entity createEntity(final World world, final Entity location, final ItemStack itemstack) {
	    return (Entity)new FireproofItemEntity(world, location, itemstack);
	}

}
