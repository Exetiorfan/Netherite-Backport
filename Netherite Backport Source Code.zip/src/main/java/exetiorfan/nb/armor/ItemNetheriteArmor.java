package exetiorfan.nb.armor;

import exetiorfan.nb.entity.FireproofItemEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemNetheriteArmor extends ItemArmor {

	public ItemNetheriteArmor(ArmorMaterial armourMaterial, int renderIndex, int armourType) {
		super(armourMaterial, renderIndex, armourType);
		
	}
	
	public boolean hasCustomEntity(final ItemStack stack) {
	    return true;
	}

	public Entity createEntity(final World world, final Entity location, final ItemStack itemstack) {
	    return (Entity)new FireproofItemEntity(world, location, itemstack);
	}
	
	@Override
	public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type)
	{
		if(this.armorType == 2)
		{
		return "nb:textures/models/armor/netherite_layer_2.png";
	    }
        return "nb:textures/models/armor/netherite_layer_1.png";
	}
}
