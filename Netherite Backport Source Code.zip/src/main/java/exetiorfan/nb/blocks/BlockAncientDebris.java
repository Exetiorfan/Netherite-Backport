package exetiorfan.nb.blocks;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import exetiorfan.nb.sounds.ModSounds;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class BlockAncientDebris extends Block { 
	
	public IIcon Side0;
	public IIcon Side1;
	public IIcon Side2;
	public IIcon Side3;
	public IIcon Side4;
	public IIcon Side5;

	public BlockAncientDebris(Material material) {
		super(material.rock);
		this.setStepSound(ModSounds.soundDebris);
		this.setResistance(2000.0F);
		this.setHardness(30.0F);
		this.setHarvestLevel("pickaxe", 3);
	}
	public void registerBlockIcons(IIconRegister icon) {
		Side0 = icon.registerIcon("nb:ancient_debris_top");
		Side1 = icon.registerIcon("nb:ancient_debris_top");
		Side2 = icon.registerIcon("nb:ancient_debris_side");
		Side3 = icon.registerIcon("nb:ancient_debris_side");
		Side4 = icon.registerIcon("nb:ancient_debris_side");
		Side5 = icon.registerIcon("nb:ancient_debris_side");
	} 
	public IIcon getIcon(int side, int meta) {
		if(side == 0) {
			return Side0;
		}else if (side == 1) {
			return Side1;
		}else if (side == 2) {
			return Side2;
		}else if (side == 3) {
			return Side3;
		}else if (side == 4) {
			return Side4;
		}else if (side == 5) {
			return Side5;
		}
		return null;
	}
}
 